"""Tools to handle the communications with a database."""
import sqlite3
import tempfile
from loguru import logger
import pandas as pd


class DB:
    def __init__(self, definitions, db_name=""):
        """Setup a new database using the variables defined in definitions."""
        self._db_name = db_name
        if self._db_name == "":
            # _db_file ensures the temp db file exists as long as the DB is not destroyed
            self._db_file = tempfile.NamedTemporaryFile()
            self._db_name = self._db_file.name
        logger.success("Database is set: {0}".format(self._db_name))
        self.connect()
        self.execute(
            "CREATE TABLE IF NOT EXISTS history (id INT UNIQUE NOT NULL, {}, is_set INT)".format(
                ", ".join(['"{0}" {1}'.format(name, type) for name, type in definitions.items()])
            )
        )

    def connect(self):
        self._conn = sqlite3.connect(self._db_name, check_same_thread=False)
        self._cur = self._conn.cursor()

    def execute(self, formula, param=()):
        res = self._cur.execute(formula, param)
        self.commit()
        return res

    def commit(self):
        self._conn.commit()

    def close(self):
        self.commit()
        self._conn.close()

    def insert(self, variables):
        """Modify a line corresponding to the current line id. A dictionary of variable is provided.

        ex:
            variables = DataFrame({'var1':[0,1,2,3], 'var1':[4,5,6,7]})
            variables = {'var1':[0,1,2,3], 'var1':[4,5,6,7]}
        """
        if type(variables) is dict:
            self.execute(
                "INSERT OR REPLACE INTO history ({names}) VALUES ({values})".format(
                    names=", ".join(['"{0}"'.format(var) for var in list(variables.keys())]),
                    values=", ".join(
                        [
                            '"{0}"'.format(val) if pd.notna(val) else "NULL"
                            for val in variables.values()
                        ]
                    ),  # you can't set np.NaN values in sqlite, only NULL
                )
            )
        else:
            for _, row in variables.iterrows():
                self.insert(row.to_dict())

    def replace(self, variables):
        """Modify a line corresponding to the current line id. A dictionary of variable is provided.

        ex:
            variables = {'var1':[0,1,2,3], 'var1':[4,5,6,7]}
        """
        formula = "REPLACE INTO history ({names}) VALUES ({values})".format(
            names=", ".join(list(variables.keys())),
            values=", ".join([str(val) for val in variables.values()]),
        )
        self.execute(formula)

    def get_current_line(self):
        data = pd.read_sql(
            "SELECT * FROM history WHERE id=(SELECT max(id) FROM history)",
            self._conn,
        )
        if len(data) == 0:
            return {}
        else:
            return {key: val[0] for key, val in data.to_dict(orient="list").items()}

    def get_history(self, N=None):
        select_id = "ORDER BY id DESC LIMIT {0}".format(N) if N != None else ""
        data = pd.read_sql("SELECT * FROM history {}".format(select_id), self._conn)
        return data

    def clear(self):
        self.execute("DELETE FROM history")
        self.execute("VACUUM")
