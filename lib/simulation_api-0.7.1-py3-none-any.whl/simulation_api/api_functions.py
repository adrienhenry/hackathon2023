"""
Functions associated to the API's endpoints.
The actual function mechanics is handled by an api_model.
"""
from . import api_model
from flask import abort
from http import HTTPStatus
import inspect

app_obj = {}


def set_model(model):
    app_obj["model"] = model


def get_model():
    return app_obj.get("model")


def chek_defined_app(func):
    """Decorator that checks that app_obj exists."""

    def wrapped(*args, **kwargs):
        if get_model() is None:
            abort(HTTPStatus.NOT_IMPLEMENTED, "No model is implemented on the API.")
        needed_kwargs = {
            key: val for key, val in kwargs.items() if key in inspect.signature(func).parameters
        }
        return func(*args, **needed_kwargs)

    return wrapped


@chek_defined_app
def get_state():
    return get_model().get_state()


@chek_defined_app
def get_history():
    return get_model().get_history()


@chek_defined_app
def change_settings(body):
    return get_model().change_settings(body)


@chek_defined_app
def initialize(body):
    return get_model().initialize(body)


@chek_defined_app
def add_state():
    return get_model().add_state()


def is_ready():
    return get_model().is_ready()
