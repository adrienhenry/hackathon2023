"""
An model handles the mechanics of each enpoints.
The methods can be overwritten to introduce a new behavior.
"""

from typing import List, Dict
import pipeline_mb_tools
from loguru import logger
from http import HTTPStatus
from flask import abort
import pandas as pd
import numpy as np
import random


class API_Model:
    def __init__(self, seed=None, param={}, db_name=""):
        self._is_ready = False
        self._param = param
        if db_name == "":
            db_name = self._param.get("database", "")
        self.set_seed(seed)
        self._contexts = self._param.get("contexts", {})
        self._settings = self._param.get("settings", {})
        self._outputs = self._param.get("outputs", {})
        self._measures = self._param.get("measures", {})
        self.setup()
        self.simu_db = pipeline_mb_tools.DB(self.get_all(), db_name)
        self._is_ready = True
        logger.info(f"{self.__class__.__name__} is ready.")

    def setup(self):
        return None

    def get_context(self):
        return self._contexts

    def get_settings(self):
        return self._settings

    def get_measures(self):
        return self._measures

    def get_outputs(self):
        return self._outputs

    def get_all(self):
        return {**self._contexts, **self._settings, **self._measures, **self._outputs}

    def get_state(self):
        data = self.simu_db.get_current_line()
        return data, HTTPStatus.OK

    def get_history(self):
        data = self.simu_db.get_history()
        return data.to_dict(orient="list"), HTTPStatus.OK

    def change_settings(self, body):
        current_state, _ = self.get_state()
        output, _ = self.run_setting(body, current_state)
        current_state.update({**output, "is_set": 1})
        self.simu_db.insert(current_state)
        return output, HTTPStatus.OK

    def run_setting(self, body, current_state=None):
        if current_state is None:
            current_state, _ = self.get_state()
        allowed_param = list(self._settings.keys())
        for key in body.keys():
            if key not in allowed_param:
                abort(
                    HTTPStatus.BAD_REQUEST,
                    "Bad request. The {0} is not a settings.".format(key),
                )
        current_state.update(body)
        try:
            predictions = self.compute_outputs(current_state)
        except NotImplementedError:
            abort(HTTPStatus.NOT_IMPLEMENTED, "The simulation is not implemented.")
        return predictions, HTTPStatus.OK

    def compute_outputs(self, param):
        raise NotImplementedError

    def initialize(self, body):
        """Clear the database. If body is not None, upload a new history."""
        self.simu_db.clear()
        if body:
            data_length = None
            for key in list(self._settings.keys()) + list(self._contexts.keys()):
                try:
                    assert key in body, "Key {0} is not in history.".format(
                        key
                    )  # Checks that all the contexts and settings are presents
                    data_length = len(body[key]) if data_length is None else data_length
                    assert (
                        len(body[key]) == data_length
                    ), "Not all columns have the same length."  # Ensures that all the columns have the same length
                except AssertionError as err:
                    abort(HTTPStatus.BAD_REQUEST, "History format error: {0}".format(err))
            data = pd.DataFrame(body)
            data["is_set"] = 0
            data = data.join(
                data.apply(lambda x: pd.Series(self.compute_outputs(x)), axis=1)
            )  # Compute the quality column
            self.simu_db.insert(data.reset_index().rename(columns={"index": "id"}))  # Add indexes
        return "The database has been successfully initialized.", HTTPStatus.OK

    def compute_next_state(self):
        raise NotImplementedError

    def add_state(self):
        new_state = self.compute_next_state()
        new_state.update({"is_set": 0})
        for var_name in self.get_all().keys():
            try:
                assert var_name in new_state, "Key {0} is not in the new state.".format(var_name)
            except AssertionError as err:
                abort(
                    HTTPStatus.INTERNAL_SERVER_ERROR,
                    "Internal server error: {0}".format(err),
                )
        self.simu_db.insert(new_state)
        return new_state, HTTPStatus.OK

    def set_seed(self, seed):
        if seed is not None:
            np.random.seed(seed)
            random.seed(seed)
            logger.info("Seed set to {0}.".format(seed))

    def is_ready(self):
        return self._is_ready
