"""Creation of the flask app."""
from loguru import logger
import connexion
from . import api_functions
import os


def create_app(name, model):
    """Create a flask app with the connexion api."""
    api_functions.set_model(model)
    dir_path = os.path.dirname(os.path.realpath(__file__))
    app = connexion.FlaskApp(name, specification_dir=os.path.join(dir_path, "openapi/"))
    app.add_api(
        "doc-openapi.yaml",
        arguments={"title": "API's endpoints"},
        strict_validation=True,
    )
    return app
